"use strict";
/**
 * @fileoverview Weather service - checks flights against weather and updates status
 * @module services/weather-service
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.weatherService = void 0;
const db_1 = require("@/lib/db");
const weather_1 = require("@/lib/weather");
const weather_validation_1 = require("./weather-validation");
const cancellation_calculator_1 = require("./cancellation-calculator");
const notification_service_1 = require("./notification-service");
const airportdb_1 = require("@/lib/airportdb");
/**
 * Weather service
 * Manages weather checks for flights and status updates
 */
class WeatherService {
    /**
     * Checks weather for a specific flight and updates status
     *
     * @param bookingId - Flight booking ID
     * @returns Updated booking with weather data
     *
     * @throws Error if booking not found or weather check fails
     */
    async checkFlightWeather(bookingId) {
        // Fetch booking
        const booking = await db_1.db.booking.findUnique({
            where: { id: bookingId },
            include: {
                student: {
                    select: {
                        trainingLevel: true,
                    },
                },
            },
        });
        if (!booking) {
            throw new Error(`Booking not found: ${bookingId}`);
        }
        const trainingLevel = booking.trainingLevel;
        let departureLocation = booking.departureLocation;
        // Fetch runway heading if missing but ICAO code is available
        if (!departureLocation.runwayHeading && departureLocation.icaoCode) {
            try {
                console.log('[Weather Service] Runway heading missing, fetching for:', departureLocation.icaoCode);
                const airportData = await airportdb_1.airportDBClient.getAirportByICAO(departureLocation.icaoCode);
                if (airportData?.runwayHeading) {
                    // Update departure location with runway heading
                    departureLocation = {
                        ...departureLocation,
                        runwayHeading: airportData.runwayHeading,
                    };
                    // Update the booking in database with runway heading
                    await db_1.db.booking.update({
                        where: { id: bookingId },
                        data: {
                            departureLocation: departureLocation,
                        },
                    });
                    console.log('[Weather Service] Fetched and stored runway heading:', airportData.runwayHeading);
                }
            }
            catch (error) {
                console.warn('[Weather Service] Failed to fetch runway heading:', error);
                // Continue with existing location data
            }
        }
        const runwayHeading = departureLocation.runwayHeading;
        console.log('[Weather Service] Checking weather for flight:', {
            bookingId,
            departureLocation,
            scheduledDate: booking.scheduledDate.toISOString(),
            trainingLevel,
            runwayHeading,
        });
        // Get weather for flight
        const weatherResponse = await (0, weather_1.getWeatherForFlight)(departureLocation, booking.scheduledDate);
        console.log('[Weather Service] Weather response received:', {
            source: weatherResponse.source,
            fetchedAt: weatherResponse.fetchedAt.toISOString(),
            weatherData: JSON.stringify(weatherResponse.data, null, 2),
        });
        // Evaluate weather safety with runway heading if available
        const evaluation = (0, weather_validation_1.evaluateWeatherSafety)(weatherResponse.data, trainingLevel, runwayHeading);
        console.log('[Weather Service] Weather evaluation:', {
            isSafe: evaluation.isSafe,
            violations: evaluation.violations,
            severityScore: evaluation.severityScore,
        });
        // Calculate cancellation probability
        const condition = {
            weather: weatherResponse.data,
            source: weatherResponse.source,
            isSafe: evaluation.isSafe,
            violations: evaluation.violations,
            severityScore: evaluation.severityScore,
        };
        const probabilityResult = (0, cancellation_calculator_1.calculateCancellationProbability)(condition, trainingLevel);
        console.log('[Weather Service] Cancellation probability calculation:', {
            probability: probabilityResult.probability,
            riskLevel: probabilityResult.riskLevel,
            reasons: probabilityResult.reasons,
        });
        // Determine new status
        const newStatus = probabilityResult.probability > 0 ? 'AT_RISK' : 'SCHEDULED';
        // Update booking
        const updatedBooking = await db_1.db.booking.update({
            where: { id: bookingId },
            data: {
                status: newStatus,
                cancellationProbability: probabilityResult.probability,
                riskLevel: probabilityResult.riskLevel,
            },
            include: {
                student: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                    },
                },
                instructor: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                    },
                },
            },
        });
        // Prepare weather data for storage - convert Date objects to ISO strings
        const weatherDataForStorage = {
            ...weatherResponse.data,
            timestamp: weatherResponse.data.timestamp instanceof Date
                ? weatherResponse.data.timestamp.toISOString()
                : typeof weatherResponse.data.timestamp === 'string'
                    ? weatherResponse.data.timestamp
                    : new Date().toISOString(),
        };
        console.log('[Weather Service] Weather data prepared for storage:', JSON.stringify(weatherDataForStorage, null, 2));
        // Log weather check
        await db_1.db.weatherLog.create({
            data: {
                bookingId,
                weatherData: weatherDataForStorage,
                weatherSource: weatherResponse.source,
                cancellationProbability: probabilityResult.probability,
                riskLevel: probabilityResult.riskLevel,
                conflictDetails: {
                    violations: evaluation.violations,
                    reasons: probabilityResult.reasons,
                },
            },
        });
        // Send notification email if conflict detected
        if (newStatus === 'AT_RISK') {
            try {
                await notification_service_1.notificationService.sendWeatherConflictEmail(updatedBooking, {
                    violations: evaluation.violations,
                    reasons: probabilityResult.reasons,
                });
            }
            catch (error) {
                console.error('[Weather Service] Failed to send notification email:', error);
                // Don't throw - notification failure shouldn't break weather check
            }
        }
        return {
            booking: updatedBooking,
            weather: weatherResponse.data,
            source: weatherResponse.source,
            probability: probabilityResult.probability,
            riskLevel: probabilityResult.riskLevel,
            violations: evaluation.violations,
        };
    }
    /**
     * Checks weather for all upcoming flights within 7 days
     *
     * @returns Summary of checks performed
     */
    async checkUpcomingFlights() {
        const now = new Date();
        const sevenDaysFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
        // Find all flights scheduled within next 7 days
        const flights = await db_1.db.booking.findMany({
            where: {
                scheduledDate: {
                    gte: now,
                    lte: sevenDaysFromNow,
                },
                status: {
                    notIn: ['CANCELLED', 'COMPLETED'],
                },
            },
            include: {
                student: {
                    select: {
                        trainingLevel: true,
                    },
                },
            },
        });
        const results = {
            checked: 0,
            atRisk: 0,
            errors: [],
        };
        // Check each flight
        for (const flight of flights) {
            try {
                const result = await this.checkFlightWeather(flight.id);
                results.checked++;
                if (result.booking.status === 'AT_RISK') {
                    results.atRisk++;
                }
            }
            catch (error) {
                results.errors.push(`Flight ${flight.id}: ${error instanceof Error ? error.message : 'Unknown error'}`);
            }
        }
        return results;
    }
}
// Export singleton instance
exports.weatherService = new WeatherService();
