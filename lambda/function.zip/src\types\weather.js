"use strict";
/**
 * @fileoverview Weather data type definitions
 * @module types/weather
 */
Object.defineProperty(exports, "__esModule", { value: true });
